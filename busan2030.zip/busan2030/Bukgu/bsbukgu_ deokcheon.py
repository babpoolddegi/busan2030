import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
from house_crawling_function import house_oneroom_scroll, house_oneroom_dataframe

result = []
imageResult = []
# 북구 덕천동
url = 'https://m.land.naver.com/map/35.2148:129.0134:14:2632010400/OR/B1:B2:B3?tag=SMALLSPCRENT#mapFullList'
result, imageResult = house_oneroom_scroll(url, result, imageResult)

result_df, image_df = house_oneroom_dataframe(result, imageResult)
print(result_df)


# 파일에 쓰기(매물 정보)
if not os.path.exists('D:/bigdataProject/file/bsBukgu.csv'):
    result_df.to_csv('D:/bigdataProject/file/bsBukgu.csv', encoding='utf-8-sig', mode='w', index=False)
else:
    result_df.to_csv('D:/bigdataProject/file/bsBukgu.csv', encoding='utf-8-sig', mode='a', index=False, header=False)

# 파일에 쓰기(이미지 경로)
if not os.path.exists('D:/bigdataProject/file/houseImage.csv'):
    image_df.to_csv('D:/bigdataProject/file/houseImage.csv', encoding='utf-8-sig', mode='w', index=False)
else:
    image_df.to_csv('D:/bigdataProject/file/houseImage.csv', encoding='utf-8-sig', mode='a', index=False, header=False)