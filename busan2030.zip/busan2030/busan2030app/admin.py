from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import House
from .models import GuGun
from .models import HouseImage
# Register your models here.

admin.site.register(House)
admin.site.register(GuGun)
admin.site.register(HouseImage)