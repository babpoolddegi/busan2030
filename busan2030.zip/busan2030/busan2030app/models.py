from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

# Create your models here.

# 구군 테이블
class GuGun(models.Model):
    # 기본키는 자동으로 만들어줌.
    # 1: 강서구 / 2: 금정구 / 3: 기장군 / 4: 남구 / 5: 동구
    # 6: 동래구 / 7: 부산진구 / 8: 북구/ 9: 사상구 / 10: 사하구
    # 11: 서구 / 12: 수영구 / 13: 연제구 / 14: 영도구 / 15: 중구
    # 16: 해운대구
    name = models.CharField(null=False, max_length=20)

#  매물 테이블
class House(models.Model):
    num = models.CharField(primary_key=True, max_length=100) # 매물번호
    title = models.CharField(null=False, max_length=100) # 원룸명
    kind = models.CharField(null=False, max_length=10) # 종류(월세/ 전세)
    securityPrice = models.IntegerField(null=False, max_length=20) # 보증금
    monthlyRent = models.IntegerField(null=False, max_length=20) # 월세
    area = models.CharField(null=False, max_length=50) # 공급/전용면적
    direction = models.CharField(null=False, max_length=50) # 방향
    rCount = models.CharField(null=False, max_length=10) # 방수/ 욕실수
    floor = models.CharField(null=False, max_length=20) # 해당층/총층
    parkingCount = models.CharField(null=False, max_length=30) # 총주차대수
    mCost = models.CharField(null=False, max_length=20) # 관리비
    mInclude = models.CharField(null=False, max_length=50) # 관리비 포함
    rStructure = models.CharField(null=False, max_length=20) # 방구조
    heating = models.CharField(null=False, max_length=40) # 난방
    approveDate = models.CharField(max_length=40) # 사용승인일
    usage = models.CharField(null=False, max_length=40) # 건축물 용도
    moveDate = models.CharField(null=False, max_length=50) # 입주가능일
    location = models.TextField(null=False) # 매물 주소
    gugun = models.ForeignKey(GuGun, on_delete=models.CASCADE) # gugun의 기본키가 들어감.
    # like = models.ManyToManyField(User, related_name='likes', blank=True)

# 매물 이미지
class HouseImage(models.Model):
    image = models.CharField(max_length=200) # 이미지url 또는 이미지 명
    house = models.ForeignKey(House, on_delete=models.CASCADE) # 매물 테이블의 기본키가 외래키로 잡힘

class WishList(models.Model):
    house = models.ForeignKey(House, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

# 게시판 관련 테이블
class Board(models.Model):
    writer = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(null=False, max_length=200)
    content = models.TextField(null=False)
    hit = models.IntegerField(default=0)
    post_date = models.DateTimeField(default=datetime.now, blank=True)
    down = models.IntegerField(default=0)
    image = models.ImageField(blank=True, null=True, upload_to="images/") # 사진
    comment_count = models.IntegerField(default=0)
    like_count = models.IntegerField(default=0)

    def hit_up(self):
        self.hit += 1

    def down_up(self):
        self.down += 1

    def comment_count_up(self):
        self.comment_count += 1
    
    def comment_count_down(self):
        self.comment_count -= 1    

    def like_count_up(self):
        self.like_count += 1

    def like_count_down(self):
        self.like_count -= 1

class Board_likes(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    board = models.ForeignKey(Board, on_delete=models.CASCADE)

class Comment(models.Model):
    board = models.ForeignKey(Board, on_delete=models.CASCADE)
    writer = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(null=False)
    post_date = models.DateTimeField(default=datetime.now, blank=True)