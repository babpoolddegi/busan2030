from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
import pandas as pd
from .form import UserForm
from django.contrib.auth import authenticate, login
from .models import House, GuGun, HouseImage, WishList, Board, Comment, Board_likes
from django.http.response import JsonResponse, HttpResponse
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import EmailMessage

# Create your views here.
UPLOAD_DIR = "C:/bigdata_project/upload/"
RealEstate_Info = 'D:/bigdataProject/'
MAX_LIST_CNT = 15
MAX_PAGE_CNT = 10

# mainpage
@csrf_exempt
def base(request):
    return render(request, 'base.html')

# 시각화
def summary(request):
    return render(request, 'summary.html')

def visual(request):
    return render(request, 'busan_gugun.html')

def visual_map(request):
    return render(request, 'busan_map.html')

def visual_gugun(request):
    gu_info = GuGun.objects.all()
    context = {'gu_info':gu_info}
    return render(request, 'busan_gugun.html', context)

# signup
def signup(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            print('signup POST is_valid')
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')

            # 사용자명과 비밀번호 검증
            user = authenticate(username=username, password=raw_password)
            # 로그인 (사용자 세션 생성)
            login(request, user)
            return redirect('/')
    else:
        form = UserForm()
    return render(request, 'user/signup.html', {'form':form})

# 상세보기
def detail(request, info_num):
    house = House.objects.get(num=info_num)
    like = WishList.objects.filter(Q(user_id=request.user.id) & Q(house_id=info_num))
    like_count = WishList.objects.filter(house_id=info_num).count()

    context = {'house':house, 'like':like, 'like_count':like_count}
    return render(request, 'house/detail.html', context)

def roomlist(request):
    # 부동산 매물을 저장하는 코드
    # data = pd.read_csv(RealEstate_Info+'image.csv', encoding='utf-8-sig', sep=',')
    
    # val_list = data.values.tolist()
    # for i in val_list:

    #     image = HouseImage(image=i[0], house_id=i[1])
    #     # #house = House(title=i[0], kind=i[1], securityPrice=i[2],monthlyRent=i[3],area=i[4],direction=i[5],rCount=i[6],floor=i[7],
    #     #                parkingCount=i[8],mCost=i[9],mInclude=i[10],rStructure=i[11],heating=i[12],approveDate=i[13],usage=i[14],moveDate=i[15],num=i[16],location=i[17],gugun_id=i[18])
    #     image.save()
        
    gu_info = GuGun.objects.all()
    detail_info = House.objects.all()
    house_img = HouseImage.objects.all()
    like_user = WishList.objects.filter(Q(user_id=request.user.id))

    # 페이징 처리
    page = request.GET.get('page', 1)
    paginator = Paginator(detail_info, MAX_LIST_CNT)
    # page_obj = paginator.get_page(page)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page = 1
        page_obj = paginator.page(page)
    except EmptyPage:
        page = paginator.num_pages
        page_obj = paginator.page(page)

    # 전체 페이지의 마지막 번호
    last_page_num = 0
    for last_page in paginator.page_range:
        last_page_num = last_page + 1

    # 현재 페이지가 몇번째 블럭인지
    current_block = ((int(page)-1) / MAX_PAGE_CNT)+1
    current_block = int(current_block)

    # 페이지 시작 번호
    page_start_number = ((current_block - 1)* MAX_PAGE_CNT) + 1

    # 페이지 끝 번호
    page_end_number = page_start_number + MAX_PAGE_CNT - 1 
    
    context = {'detail_info':detail_info, 'gu_info':gu_info, 'page_obj':page_obj, 'last_page_num':last_page_num, 
               'page_start_number':page_start_number, 'page_end_number':page_end_number, 'imgUrl':house_img, 'like_user':like_user}
    return render(request, 'house/roomlist.html', context)

# select박스 클릭될때    
def search(request, id, type, price):
   
    if id==0:
        searchHouse = House.objects.all()
        if type == 1:
            if price == 0:
                searchHouse = House.objects.filter(Q(kind__contains='전세')).order_by('securityPrice')
            else:
                searchHouse = House.objects.filter(Q(kind__contains='전세')).order_by('-securityPrice')
        elif type == 2:
            if price == 0:
                searchHouse = House.objects.filter(Q(kind__contains='월세')).order_by('monthlyRent')
            else:
                searchHouse = House.objects.filter(Q(kind__contains='월세')).order_by('-monthlyRent')
        elif type == 3:
            if price == 0:
                searchHouse = House.objects.filter(Q(kind__contains='단기임대')).order_by('securityPrice')
            else:
                searchHouse = House.objects.filter(Q(kind__contains='단기임대')).order_by('-securityPrice')
        else :
            searchHouse = House.objects.filter(gugun_id=id)
    
    else:
        # searchHouse = House.objects.filter(gugun_id=id)
        # field = request.GET.get('field', id)
        if type == 1:
            if price == 0:
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='전세')).order_by('securityPrice')
            else :
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='전세')).order_by('-securityPrice')
        elif type == 2:
            if price == 0:
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='월세')).order_by('monthlyRent')
            else :
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='월세')).order_by('-monthlyRent')
        elif type == 3:
            if price == 0:
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='단기임대')).order_by('securityPrice')
            else :
                searchHouse = House.objects.filter(Q(gugun_id = id) & Q(kind__contains='단기임대')).order_by('-securityPrice')
        else :
            searchHouse = House.objects.filter(gugun_id=id)
   
  
    gu_info = GuGun.objects.all()
    house_img = HouseImage.objects.all()
    house_img = HouseImage.objects.all()
    like_user = WishList.objects.filter(Q(user_id=request.user.id))

      # 페이징 처리
    page = request.GET.get('page', 1)
    paginator = Paginator(searchHouse, MAX_LIST_CNT)
    # page_obj = paginator.get_page(page)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page = 1
        page_obj = paginator.page(page)
    except EmptyPage:
        page = paginator.num_pages
        page_obj = paginator.page(page)

    # 전체 페이지의 마지막 번호
    last_page_num = 0
    for last_page in paginator.page_range:
        last_page_num = last_page + 1

    # 현재 페이지가 몇번째 블럭인지
    current_block = ((int(page)-1) / MAX_PAGE_CNT)+1
    current_block = int(current_block)

    # 페이지 시작 번호
    page_start_number = ((current_block - 1)* MAX_PAGE_CNT) + 1

    # 페이지 끝 번호
    page_end_number = page_start_number + MAX_PAGE_CNT - 1 
    context = {'detail_info':searchHouse, 'gu_info':gu_info, 'page_obj':page_obj, 'last_page_num':last_page_num, 
               'page_start_number':page_start_number, 'page_end_number':page_end_number, 'field':id, 'type':type, 'price':price, 'like_user':like_user}
    return render(request, 'house/roomlist.html', context)
# 좋아요 클릭 시
@csrf_exempt
def wishlist(request, num):
    # num = request.POST['num'] # 매물번호
    cur_user = request.user

    if cur_user.is_authenticated:  # 로그인이 되었다면
        # house = House.objects.get(num=num)
        # count = house.like.count()  # 좋아요 개수
        
       # 좋아요 눌렀는지 확인
        like = WishList.objects.filter(Q(user_id=request.user.id) & Q(house_id=num))
        if like:
            like = 1
        else:
            like = 0
        

        if like == 1:  # 좋아요가 눌러져 있다면
            WishList.objects.filter(Q(house_id=num)&Q(user_id=request.user.id)).delete()
            count  = WishList.objects.filter(house_id=num).count()
            like = 0
            return JsonResponse({'like':'white', 'count':count})
        else:
            wishlist = WishList(house_id=num, user_id=request.user.id)
            wishlist.save()
            count  = WishList.objects.filter(house_id=num).count()
            like = 1
            return JsonResponse({'like':'red', 'count':count})

        # if request.user in house.like.all():
        #     house.like.remove(request.user)
        #     count = house.like.count()  # 좋아요 개수
        #     return JsonResponse({'like':'white', 'count':count})
        # else:
        #     house.like.add(request.user)
        #     count = house.like.count()  # 좋아요 개수
        #     return JsonResponse({'like':'red', 'count':count})
    else:
        return JsonResponse({'login':'nologin'})

# 마이페이지
def mypage(request):

    wishlist = WishList.objects.filter(user_id=request.user.id)
    count = WishList.objects.filter(user_id=request.user.id).count()
    context = {'wishlist':wishlist, 'count':count}
    return render(request,'mypage.html', context)

# 마이페이지에서의 좋아요한 매물 삭제
def mypageDelete(request, num):
    WishList.objects.filter(Q(house_id=num)&Q(user_id=request.user.id)).delete()
    return JsonResponse({'delete':'delete'})


# 게시판
# write_form
@login_required(login_url='/login/') # 로그인한 사람만 글쓰기가능하도록.
def write_form(request):
    return render(request, "board/insert.html")

# 게시글 insert
@csrf_exempt
def insert(request):
    image = None

    if 'image' in request.FILES:
        image = request.FILES['image']

    board = Board(writer = request.user,  # writer > 유저객체를 통해 받아와야함.
                  title = request.POST['title'],
                  content = request.POST['content'],
                  image = image)
    board.save()
    return redirect('/list/')

# 게시글 list
def list(request):
    page = request.GET.get('page', 1)
    word = request.GET.get('word','')
    sort = request.GET.get('sort','')

    boardCount = Board.objects.filter(Q(writer__username__contains = word)|
                                      # 글쓴이는 유저객체임 : writer 에 들어있는 username 안에 word가 있는지.
                                      Q(title__contains = word)|
                                      Q(content__contains = word)).count()
    
    if sort == 'likes':
        boardList = Board.objects.filter(Q(writer__username__contains = word)|
                                         Q(title__contains = word)|
                                         Q(content__contains = word)).order_by('-like_count', '-id')
    elif sort == 'comments':
        boardList = Board.objects.filter(Q(writer__username__contains = word)|
                                         Q(title__contains = word)|
                                         Q(content__contains = word)).order_by('-comment_count', '-id')
    elif sort == 'hits':
        boardList = Board.objects.filter(Q(writer__username__contains = word)|
                                         Q(title__contains = word)|
                                         Q(content__contains = word)).order_by('-hit', '-id')
    else :
        boardList = Board.objects.filter(Q(writer__username__contains = word)|
                                         Q(title__contains = word)|
                                         Q(content__contains = word)).order_by('-id')
    
    ###### 페이징 ######
    pageSize = 5
    paginator = Paginator(boardList, pageSize)
    page_obj = paginator.get_page(page)
    print('page_obj : ', page_obj)

    # 한 페이지의 스타트 글번호. 총 게시글수가 9개라면 1페이지는 9,8,7,6,5 2페이지는 4,3,2,1
    rowNo = boardCount - (int(page)-1)*pageSize

    context = {'word':word,
               'sort':sort,
               'boardCount':boardCount,
               'page_list' : page_obj,
               'rowNo' : rowNo}

    return render(request, 'board/list.html', context)

# 글 상세보기 detail
def board_detail(request, board_id):
    board = Board.objects.get(id=board_id)
    board.hit_up()
    board.save()

    print('*************************',request.user.id, board_id,'*****************************')

    commentList = Comment.objects.filter(board_id=board_id).order_by('-id')
    commentCount = Comment.objects.filter(board_id=board_id).order_by('-id').count()
    blike = Board_likes.objects.filter(Q(user_id=request.user.id) & Q(board_id=board_id))
    return render(request, "board/detail.html", {'board' : board, 'commentList' : commentList, 'commentCount' : commentCount, 'blike':blike})

# 게시글 좋아요
@csrf_exempt
def like(request,board_id):

    # 어떤 게시물에, 어떤 사람이 like를 했는 지
    # board = Board.objects.get(id=bid) # 게시물 번호 몇번인지 정보 가져옴
    # user = request.user
    # if board.like.filter(id=request.user.id).exists(): # 유저면 알아서 유저의 id로 검색해줌
    #     board.like.remove(user)
    #     return JsonResponse({'message': 'line', 'like_cnt' : board.like.count() })
    # else:
    #     board.like.add(user) # post의 like에 현재유저의 정보를 넘김
    #     return JsonResponse({'message': 'color', 'like_cnt' : board.like.count()})

    # cur_user = request.user
    # if cur_user.is_authenticated:
    #     board = Board.objects.get(id=board_id)
    #     if request.user in board.like.all():
    #         board.like.remove(request.user)
    #         return JsonResponse({'like':'line', 'count': board.like.count()})
    #     else:
    #         board.like.add(request.user)
    #         return JsonResponse({'like':'color', 'count': board.like.count()})
    # else:
    #     return JsonResponse({'login':'nologin'})

    user = request.user
    board = Board.objects.get(id=board_id)

    print('*************************',user,'/',board,'/','*****************************')

    if user.is_authenticated : 
        exist = Board_likes.objects.filter(user = user, board = board).count()
        if exist == 0:
            board_like = Board_likes(user = user, board = board)
            board_like.save()
            board.like_count_up()
            board.save()
            count = board.like_count
            return JsonResponse({'like':'color', 'count': count})        
        else :
            Board_likes.objects.get(user = user, board = board).delete()
            board.like_count_down()
            board.save()
            count = board.like_count
            return JsonResponse({'like':'line', 'count': count})
    else :
        return JsonResponse({'login':'nologin'})

# update_form
def update_form(request, board_id):
    board = Board.objects.get(id=board_id)
    return render(request, "board/update.html", {'board' : board})

# update
@csrf_exempt
def update(request):
    id = request.POST['id']
    board = Board.objects.get(id=id)
    image = board.image

    if 'image' in request.FILES:
        image = request.FILES['image']
    
    dto_update = Board(id,
                       writer = request.user,
                       title = request.POST['title'],
                       content = request.POST['content'],
                       image = image)
    dto_update.save()
    return redirect('/board_detail/'+id)

# 게시글 삭제 delete
def delete(request, board_id):
    Board.objects.get(id=board_id).delete()
    return redirect('/list/')

# 댓글추가 comment_insert
@csrf_exempt
def comment_insert(request):
    id = request.POST['id']
    board = Board.objects.get(id=id)
    board.comment_count_up()
    board.save()
    comment = Comment(board = board,
                      writer = request.user,
                      content = request.POST['content'])
    comment.save()
    return redirect('/board_detail/'+id)

# 댓글삭제 comment_delete
def comment_delete(request, comment_id):
    comment = Comment.objects.get(id=comment_id)
    print(comment.board_id)
    board = Board.objects.get(id=comment.board_id)
    board.comment_count_down()
    board.save()
    comment.delete()
    return render(request, 'board/detail.html')

#관리자가 이메일 보내기
def send_email_form(request):
    # subject = "message" #타이틀
    if request.method == "POST":
        subject = request.POST.get('subject')
        to = [request.POST.get('email')] #수신할 이메일
        from_email =  "hansol4630@naver.com"#발신할 이메일
        message = request.POST.get('message')

    EmailMessage(subject=subject, body=message, to=to, from_email=from_email).send()
    return render(request,'summary.html',{})

def send_email(request):
    return render(request,'email.html',{})