from django.apps import AppConfig


class Busan2030AppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "busan2030app"
