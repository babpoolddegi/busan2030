import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
from house_crawling_function import house_oneroom_scroll, house_oneroom_dataframe

result = []
imageResult = []
# 중구 보수동3가
url = 'https://m.land.naver.com/map/35.10449:129.022462:14:2611012200/OR/B1:B2:B3?tag=SMALLSPCRENT#mapFullList'
result, imageResult = house_oneroom_scroll(url, result, imageResult)

result_df, image_df = house_oneroom_dataframe(result, imageResult)
print(result_df)


# 파일에 쓰기(매물 정보)
if not os.path.exists('D:/bigdataProject/file/bsJunggu.csv'):
    result_df.to_csv('D:/bigdataProject/file/bsJunggu.csv', encoding='utf-8-sig', mode='w', index=False)
else:
    result_df.to_csv('D:/bigdataProject/file/bsJunggu.csv', encoding='utf-8-sig', mode='a', index=False, header=False)

# 파일에 쓰기(이미지 경로)
if not os.path.exists('D:/bigdataProject/file/houseImage.csv'):
    image_df.to_csv('D:/bigdataProject/file/houseImage.csv', encoding='utf-8-sig', mode='w', index=False)
else:
    image_df.to_csv('D:/bigdataProject/file/houseImage.csv', encoding='utf-8-sig', mode='a', index=False, header=False)