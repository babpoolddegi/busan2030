from selenium import webdriver as wd
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

import re
import pandas as pd


# 스크롤 적용x(원룸을 크롤링하는 함수)
def house_oneroom(url, result, imageResult):
    path = 'D:\\chromedriver_win32\\chromedriver.exe'
    options = wd.ChromeOptions()
    options.add_experimental_option('detach', True)
    driver = wd.Chrome(path, options=options)
    driver.get(url)

     # 매물 목록 클릭
    driver.find_element(By.CLASS_NAME, '_article').send_keys(Keys.ENTER)
    time.sleep(2)

    all_div = driver.find_element(By.CLASS_NAME, 'article_box')
    a = all_div.find_elements(By.CLASS_NAME, '_innerLink')

    for item in a:
        item.send_keys(Keys.ENTER) 
        time.sleep(3)

        # 프레임 전환(ifrma안에 html코드가 들어있기 때문애)
        content = driver.find_element(By.TAG_NAME, 'iframe')
        driver.switch_to.frame(content)

        # 부동산 크롤링
        temp = []
        title = driver.find_element(By.CLASS_NAME, 'detail_sale_title').text   # 매물 이름
        temp.append(title)

        kind = driver.find_element(By.CLASS_NAME, 'detail_deal_kind').text  # 매물 종류(월세/전세)
        temp.append(kind)

        price = driver.find_element(By.CLASS_NAME, 'detail_deal_price').text # 매물 가격(보증금/전월세)
        if kind == '월세':
            price = re.split('\n만원\n/ ', price)  # 보증금과 전세월세를 나누기 위해 사용
            security_price = price[0]  # 보증금
            monthly_rent = price[1]  # 전월세 가격
            temp.append(security_price)
            temp.append(monthly_rent)
        else:
             price = re.split('\n', price)[0]
             temp.append(price)
             temp.append('-')

        # 매물 이미지 크롤링
        tempImage = []
        imageButton = driver.find_elements(By.CLASS_NAME, 'detail_photo_item')
        for image in imageButton:
            # 이미지Url 크롤링
            image = image.get_attribute('style')
            imageUrl = image.replace('background-image: url(\"', '')
            imageUrl = imageUrl.replace('\");', '')
            # 매물번호를 가지고 오기 위해서 사용
            num = re.sub('https://m.land.naver.com/article/info/', '', driver.current_url)
            imageResult.append([imageUrl, num])

        table = driver.find_element(By.CLASS_NAME, 'detail_sale_table')
        table_cell = table.find_elements(By.CLASS_NAME, 'detail_cell_data')
        for index, data in enumerate(table_cell):
            if index == 0:
                area = data.text.replace('\n평', '')
                temp.append(area)
            else :
                temp.append(data.text)

        location = driver.find_element(By.CLASS_NAME, 'detail_info_branch').text
        temp.append(location)
        result.append(temp)

        driver.back() # 뒤로가기

    return result, imageResult

# 스크롤 적용(원룸을 크롤링하는 함수)
def house_oneroom_scroll(url, result, imageResult):
    path = 'D:\\chromedriver_win32\\chromedriver.exe'
    options = wd.ChromeOptions()
    options.add_experimental_option('detach', True)
    driver = wd.Chrome(path, options=options)
    driver.get(url)

     # 매물 목록 클릭
    driver.find_element(By.CLASS_NAME, '_article').send_keys(Keys.ENTER)
    time.sleep(2)

    # 스크롤 내리기
    element = driver.find_element(By.CLASS_NAME,'article_box--sale')

    #스크롤 내리기 이동 전 위치
    last_height =  driver.execute_script("return arguments[0].scrollHeight", element)
    print('last_height :',last_height)

    while True:
        #현재 스크롤의 가장 아래로 내림
        driver.execute_script("arguments[0].scrollTo(0, arguments[0].scrollHeight)", element, element)
        # 대기
        time.sleep(2)

        # 다시 현재 브라우저의 창의 높이를 구합니다.
        # 늘어난 스크롤 높이
        new_height =  driver.execute_script("return arguments[0].scrollHeight", element)
        print('new_height :', new_height)
    
         #늘어난 스크롤 위치와 이동 전 위치 같으면(더 이상 스크롤이 늘어나지 않으면) 종료
        if last_height == new_height:
            print('화면길이 같으므로 반복 종료')
            break

        # 같지 않으면 스크롤 위치 값을 수정하여 같아질 때까지 반복
        last_height = new_height

    all_div = driver.find_element(By.CLASS_NAME, 'article_box')
    a = all_div.find_elements(By.CLASS_NAME, '_innerLink')

    for item in a:
        item.send_keys(Keys.ENTER) 
        time.sleep(3)

        # 프레임 전환(ifrma안에 html코드가 들어있기 때문애)
        content = driver.find_element(By.TAG_NAME, 'iframe')
        driver.switch_to.frame(content)

        # 부동산 크롤링
        temp = []
        title = driver.find_element(By.CLASS_NAME, 'detail_sale_title').text   # 매물 이름
        temp.append(title)

        kind = driver.find_element(By.CLASS_NAME, 'detail_deal_kind').text  # 매물 종류(월세/전세)
        temp.append(kind)

        # 매물 가격(보증금/전월세)
        price = driver.find_element(By.CLASS_NAME, 'detail_deal_price').text 
        if kind == '월세':
            price = re.split('\n만원\n/ ', price)  # 보증금과 전세월세를 나누기 위해 사용
            security_price = price[0]  # 보증금
            monthly_rent = price[1]  # 전월세 가격
            temp.append(security_price)
            temp.append(monthly_rent)
        else:
             price = re.split('\n', price)[0]
             temp.append(price)
             temp.append('-')

        # 매물 이미지 크롤링
        tempImage = []
        imageButton = driver.find_elements(By.CLASS_NAME, 'detail_photo_item')
        for image in imageButton:
            # 이미지Url 크롤링
            image = image.get_attribute('style')
            imageUrl = image.replace('background-image: url(\"', '')
            imageUrl = imageUrl.replace('\");', '')
            # 매물번호를 가지고 오기 위해서 사용
            num = re.sub('https://m.land.naver.com/article/info/', '', driver.current_url)
            imageResult.append([imageUrl, num])
        
        # 매물정보 크롤링
        table = driver.find_element(By.CLASS_NAME, 'detail_sale_table')
        table_cell = table.find_elements(By.CLASS_NAME, 'detail_cell_data')
        for index, data in enumerate(table_cell):
            if index == 0:
                area = data.text.replace('\n평', '')
                temp.append(area)
            else :
                temp.append(data.text)

        location = driver.find_element(By.CLASS_NAME, 'detail_info_branch').text
        temp.append(location)
        result.append(temp)

        driver.back() # 뒤로가기
    
    return result, imageResult

# 원룸에 대한 DataFrame
def house_oneroom_dataframe(result, imageResult):
    # 매물 정보에 대한 dataframe
    col_name = ['title', 'kind', 'securityPrice', 'monthlyRent', 'area','direction', 'rCount', 'floor', 'parkingCount',
                'mCost', 'mInclude', 'rStructure', 'heating', 'approveDate', 'usage', 'moveDate', 'num', 'location']
    oneroom_df = pd.DataFrame(result, columns=col_name)

    # 보증금(,)의 전처리
    oneroom_df['securityPrice'] = oneroom_df['securityPrice'].str.replace(',','')

    # 보증금(억)의 전처리
    oneroom_df.loc[oneroom_df['securityPrice']=='1억', 'securityPrice'] = '10000'
    oneroom_df['securityPrice'] = oneroom_df['securityPrice'].str.replace(pat=r'억', repl=r'', regex=True)
    oneroom_df['securityPrice'] = oneroom_df['securityPrice'].str.replace(' ', '') # 공백제거
    oneroom_df['securityPrice'].astype('int64')

    # 월세 전처리
    oneroom_df.loc[oneroom_df['monthlyRent']=='-', 'monthlyRent'] = '0'
    oneroom_df['monthlyRent'].astype('int64')
    
    # 이미지 크롤링한것을 데이터프레임으로 저장
    col_name1 = ['imageUrl', 'num']
    oneroom_image = pd.DataFrame(imageResult, columns=col_name1)
    return oneroom_df, oneroom_image
    




       