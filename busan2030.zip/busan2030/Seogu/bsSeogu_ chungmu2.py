from house_crawling_function import house_oneroom, house_oneroom_scroll, house_oneroom_dataframe
import os

result = []
# 서구 충무동2가
url = 'https://m.land.naver.com/map/35.095264:129.022325:14:2614012100/OR/B1:B2:B3?tag=SMALLSPCRENT#mapFullList'
house_oneroom_scroll(url, result)

df = house_oneroom_dataframe(result)
print(df)

# 파일에 쓰기
if not os.path.exists('./file/bsSeogu.csv'):
    df.to_csv('./file/bsSeogu.csv', encoding='utf-8-sig', mode='w', index=False)
else:
    df.to_csv('./file/bsSeogu.csv', encoding='utf-8-sig', mode='a', index=False, header=False)